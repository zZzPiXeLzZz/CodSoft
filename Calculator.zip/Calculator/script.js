let displayElement = document.getElementById('display');
let currentInput = '';

function clearDisplay() {
    currentInput = '';
    displayElement.innerText = '0';
}

function deleteLast() {
    currentInput = currentInput.slice(0, -1);
    displayElement.innerText = currentInput || '0';
}

function appendNumber(number) {
    currentInput += number;
    displayElement.innerText = currentInput;
}

function appendOperator(operator) {
    const lastChar = currentInput.slice(-1);
    if ('+-*/'.includes(lastChar)) {
        currentInput = currentInput.slice(0, -1); // Replace last operator
    }
    currentInput += operator;
    displayElement.innerText = currentInput;
}

function calculateResult() {
    try {
        const result = eval(currentInput);
        displayElement.innerText = result;
        currentInput = result.toString();
    } catch (error) {
        displayElement.innerText = 'Error';
        currentInput = '';
    }
}